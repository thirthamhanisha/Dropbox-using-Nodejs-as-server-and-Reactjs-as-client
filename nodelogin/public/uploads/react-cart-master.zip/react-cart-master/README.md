A basic shopping cart using React JS.

To run, pull, then navigate to directory and call `python -m SimpleHTTPServer`, finally visit: `http://localhost:8000/` to view. If this doesn't work PM me :-)

Currently you can use the controls to adjust the quantities of each cart item.

Consumes dummy JSON data meant to mimic a call to a API.

Discount functionality is hard-coded to 10%.

Negative values will work in the rows, so don't use in production :-P.

Utilises modular BEM and provides an example of how this might look in a SASS context, css declarations should be absolutely encapsulated.
