var cartItems = [
  {
    id: 1,
    name: 'Apple',
    qty: 3,
    price: 0.45
  },
  {
    id: 2,
    name: 'Banana',
    qty: 1,
    price: 0.35
  },
  {
    id: 3,
    name: 'Parsnip',
    qty: 1,
    price: 0.50
  },
  {
    id: 4,
    name: 'Potato',
    qty: 10,
    price: 0.10
  },
  {
    id: 5,
    name: 'Honey Pot',
    qty: 2,
    price: 3.50
  }
];
